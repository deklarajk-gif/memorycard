document.addEventListener('DOMContentLoaded', () => {
    // Elemen DOM
    const levelSelection = document.querySelector('.level-selection');
    const gameInfo = document.querySelector('.game-info');
    const gameTable = document.querySelector('.game-table');
    const gameBoard = document.getElementById('game-board');
    const timerElement = document.getElementById('time');
    const movesElement = document.getElementById('moves');
    const pairsElement = document.getElementById('pairs');
    const currentLevelElement = document.getElementById('current-level');
    const restartButton = document.getElementById('restart');
    const changeLevelButton = document.getElementById('change-level');
    const winMessage = document.getElementById('win-message');
    const finalTimeElement = document.getElementById('final-time');
    const finalMovesElement = document.getElementById('final-moves');
    const finalLevelElement = document.getElementById('final-level');
    const playAgainButton = document.getElementById('play-again');
    const newLevelButton = document.getElementById('new-level');
    const loseMessage = document.getElementById('lose-message');
    const loseLevelElement = document.getElementById('lose-level');
    const losePairsElement = document.getElementById('lose-pairs');
    const retryButton = document.getElementById('retry');
    const loseChangeLevelButton = document.getElementById('lose-change-level');

    // Elemen Sound
    const backgroundMusic = document.getElementById('background-music');
    const flipSound = document.getElementById('flip-sound');
    const matchSound = document.getElementById('match-sound');
    const winSound = document.getElementById('win-sound');
    const loseSound = document.getElementById('lose-sound');
    const musicToggle = document.getElementById('music-toggle');
    const soundToggle = document.getElementById('sound-toggle');
    const volumeSlider = document.getElementById('volume-slider');
    const musicStatus = document.getElementById('music-status');
    const soundStatus = document.getElementById('sound-status');

    // Variabel game
    let cards = [];
    let flippedCards = [];
    let matchedPairs = 0;
    let moves = 0;
    let timer;
    let timeLeft = 0;
    let gameStarted = false;
    let canFlip = true;
    let currentLevel = '';

    // Pengaturan sound
    let musicEnabled = true;
    let soundEnabled = true;
    let userInteracted = false;
    let backgroundMusicStarted = false;

    // Konfigurasi level
    const levelConfig = {
        easy: {
            time: 360, // 6 menit
            name: 'Easy'
        },
        normal: {
            time: 180, // 3 menit
            name: 'Normal'
        },
        hard: {
            time: 120, // 2 menit
            name: 'Hard'
        },
        impossible: {
            time: 60, // 1 menit
            name: 'Impossible'
        }
    };

    // Daftar gambar dari folder custom (20 gambar)
    const imagePaths = [
        'custom/image1.jpg',
        'custom/image2.jpg',
        'custom/image3.jpg',
        'custom/image4.jpg',
        'custom/image5.jpg',
        'custom/image6.jpg',
        'custom/image7.jpg',
        'custom/image8.jpg',
        'custom/image9.jpg',
        'custom/image10.jpg',
        'custom/image11.jpg',
        'custom/image12.jpg',
        'custom/image13.jpg',
        'custom/image14.jpg',
        'custom/image15.jpg',
        'custom/image16.jpg',
        'custom/image17.jpg',
        'custom/image18.jpg',
        'custom/image19.jpg',
        'custom/image20.jpg'
    ];

    // Fungsi untuk menandai bahwa user sudah berinteraksi
    function markUserInteracted() {
        if (!userInteracted) {
            userInteracted = true;
            console.log('User interacted, sound can now autoplay');
            // Mulai background music setelah interaksi pertama
            ensureBackgroundMusic();
        }
    }

    // Event listener untuk interaksi user pertama
    document.addEventListener('click', markUserInteracted);
    document.addEventListener('keydown', markUserInteracted);
    document.addEventListener('touchstart', markUserInteracted);

    // Inisialisasi sound
    function initializeSound() {
        // Set volume awal
        updateVolume();
        
        // Set background music untuk loop
        backgroundMusic.loop = true;
        
        // Preload audio untuk menghindari jeda
        backgroundMusic.load();
        winSound.load();
        loseSound.load();
        
        console.log('Sound system initialized - ready to play');
    }

    // Update volume semua sound
    function updateVolume() {
        const volume = volumeSlider.value / 100;
        backgroundMusic.volume = volume;
        flipSound.volume = Math.min(volume * 1.2, 1.0);
        matchSound.volume = Math.min(volume * 1.5, 1.0);
        winSound.volume = Math.min(volume * 1.3, 1.0);
        loseSound.volume = Math.min(volume * 1.3, 1.0);
    }

    // Play sound dengan pengecekan enabled
    function playSound(soundElement) {
        if (soundEnabled && userInteracted) {
            soundElement.currentTime = 0;
            soundElement.play().catch(e => {
                console.log('Error playing sound:', e);
            });
        }
    }

    // Fungsi untuk memastikan background music berjalan (tanpa mengulang)
    function ensureBackgroundMusic() {
        if (musicEnabled && userInteracted && !backgroundMusicStarted) {
            backgroundMusicStarted = true;
            backgroundMusic.play().catch(e => {
                console.log('Error starting background music:', e);
                backgroundMusicStarted = false;
            });
        }
    }

    // Fungsi untuk melanjutkan background music (jika sudah berjalan)
    function resumeBackgroundMusic() {
        if (musicEnabled && userInteracted && backgroundMusic.paused && backgroundMusicStarted) {
            backgroundMusic.play().catch(e => {
                console.log('Error resuming background music:', e);
            });
        }
    }

    // Fungsi untuk menghentikan background music
    function stopBackgroundMusic() {
        if (backgroundMusicStarted) {
            backgroundMusic.pause();
            // JANGAN reset currentTime agar tidak mengulang
        }
    }

    // Fungsi untuk menghentikan semua sound effects
    function stopAllSoundEffects() {
        flipSound.pause();
        flipSound.currentTime = 0;
        matchSound.pause();
        matchSound.currentTime = 0;
        winSound.pause();
        winSound.currentTime = 0;
        loseSound.pause();
        loseSound.currentTime = 0;
    }

    // Event listener untuk sound controls
    musicToggle.addEventListener('click', () => {
        musicEnabled = !musicEnabled;
        if (musicEnabled) {
            // Resume background music
            resumeBackgroundMusic();
            musicStatus.textContent = 'Musik: ON';
            musicToggle.classList.remove('muted');
        } else {
            stopBackgroundMusic();
            musicStatus.textContent = 'Musik: OFF';
            musicToggle.classList.add('muted');
        }
    });

    soundToggle.addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        if (soundEnabled) {
            soundStatus.textContent = 'SFX: ON';
            soundToggle.classList.remove('muted');
        } else {
            soundStatus.textContent = 'SFX: OFF';
            soundToggle.classList.add('muted');
        }
    });

    volumeSlider.addEventListener('input', updateVolume);

    // Event listener untuk tombol level
    document.querySelectorAll('.level-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const level = e.target.dataset.level;
            // Pastikan user sudah berinteraksi untuk sound
            markUserInteracted();
            // Stop semua sound effects sebelum mulai game baru
            stopAllSoundEffects();
            startGame(level);
        });
    });

    // Fungsi untuk memulai game dengan level tertentu
    function startGame(level) {
        currentLevel = level;
        const config = levelConfig[level];
        
        // Reset variabel game
        cards = [];
        flippedCards = [];
        matchedPairs = 0;
        moves = 0;
        timeLeft = config.time;
        gameStarted = false;
        canFlip = true;
        
        // Update UI
        levelSelection.classList.add('hidden');
        gameInfo.classList.remove('hidden');
        gameTable.classList.remove('hidden');
        winMessage.classList.add('hidden');
        loseMessage.classList.add('hidden');
        
        movesElement.textContent = moves;
        pairsElement.textContent = `${matchedPairs}/20`;
        timerElement.textContent = formatTime(timeLeft);
        timerElement.classList.remove('timer-warning');
        
        // Update tampilan level
        currentLevelElement.textContent = config.name;
        currentLevelElement.className = '';
        currentLevelElement.classList.add(`level-${level}`);
        
        // Hapus kartu lama
        gameBoard.innerHTML = '';
        
        // Buat pasangan kartu (40 kartu total)
        const cardValues = [...imagePaths, ...imagePaths];
        
        // Acak urutan kartu
        shuffleArray(cardValues);
        
        // Buat elemen kartu
        cardValues.forEach((imagePath, index) => {
            const card = document.createElement('div');
            card.classList.add('card');
            card.dataset.index = index;
            card.dataset.value = imagePath;
            
            const cardFront = document.createElement('div');
            cardFront.classList.add('card-front');
            
            const img = document.createElement('img');
            img.src = imagePath;
            img.alt = `Gambar ${index % 20 + 1}`;
            img.onerror = function() {
                // Jika gambar gagal dimuat, tampilkan placeholder
                this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDEwMCAxMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIiBmaWxsPSIjMzQ0OTVFIi8+CjxwYXRoIGQ9Ik01MCAzM0M0MS4xNjM0IDMzIDM0IDQwLjE2MzQgMzQgNTBDMzQgNTkuODM2NiA0MS4xNjM0IDY3IDUwIDY3QzU4LjgzNjYgNjcgNjYgNTkuODM2NiA2NiA1MEM2NiA0MC4xNjM0IDU4LjgzNjYgMzMgNTAgMzNaIiBmaWxsPSIjN0E4OEFCIi8+CjxwYXRoIGQ9Ik01MCA0MEM0NC40NzcgNCA0MCA0NC40NzcgNDAgNTBDNDAgNTUuNTIzIDQ0LjQ3NyA2MCA1MCA2MEM1NS41MjMgNjAgNjAgNTUuNTIzIDYwIDUwQzYwIDQ0LjQ3cyA1NS41MjMgNDAgNTAgNDBaIiBmaWxsPSIjOTRBNUFFIi8+CjxjaXJjbGUgY3g9IjUwIiBjeT0iNTAiIHI9IjgiIGZpbGw9IiNBOUI5QkMiLz4KPHN2Zz4K';
                this.alt = 'Gambar tidak tersedia';
            };
            
            cardFront.appendChild(img);
            
            const cardBack = document.createElement('div');
            cardBack.classList.add('card-back');
            cardBack.textContent = '?';
            
            card.appendChild(cardFront);
            card.appendChild(cardBack);
            
            card.addEventListener('click', flipCard);
            
            gameBoard.appendChild(card);
            cards.push(card);
        });
        
        // Hentikan timer sebelumnya jika ada
        clearInterval(timer);
        
        // Background music TETAP BERJALAN tanpa diulang
        // Tidak perlu memulai ulang karena sudah berjalan
    }

    // Fungsi untuk mengacak array
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    // Fungsi untuk memformat waktu
    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }

    // Fungsi untuk memulai timer
    function startTimer() {
        timer = setInterval(() => {
            timeLeft--;
            timerElement.textContent = formatTime(timeLeft);
            
            // Peringatan waktu hampir habis
            if (timeLeft <= 30) {
                timerElement.classList.add('timer-warning');
            }
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                showLoseMessage();
            }
        }, 1000);
    }

    // Fungsi untuk membalik kartu
    function flipCard() {
        if (!canFlip) return;
        
        // Jika kartu sudah terbuka, sudah cocok, atau sedang dalam proses animasi, abaikan
        if (this.classList.contains('flipped') || 
            this.classList.contains('matched')) {
            return;
        }
        
        // Jika game belum dimulai, mulai timer
        if (!gameStarted) {
            gameStarted = true;
            startTimer();
        }
        
        // Play flip sound
        playSound(flipSound);
        
        // Balik kartu
        this.classList.add('flipped');
        flippedCards.push(this);
        
        // Jika dua kartu terbuka, periksa kecocokan
        if (flippedCards.length === 2) {
            moves++;
            movesElement.textContent = moves;
            canFlip = false;
            
            setTimeout(checkMatch, 600);
        }
    }

    // Fungsi untuk memeriksa kecocokan kartu
    function checkMatch() {
        const [card1, card2] = flippedCards;
        const isMatch = card1.dataset.value === card2.dataset.value;
        
        if (isMatch) {
            // Play match sound
            playSound(matchSound);
            
            // Kartu cocok - tandai sebagai matched dan biarkan terbuka
            card1.classList.add('matched');
            card2.classList.add('matched');
            card1.removeEventListener('click', flipCard);
            card2.removeEventListener('click', flipCard);
            matchedPairs++;
            pairsElement.textContent = `${matchedPairs}/20`;
            
            // Periksa apakah game selesai
            if (matchedPairs === 20) {
                setTimeout(() => {
                    clearInterval(timer);
                    showWinMessage();
                }, 500);
            }
        } else {
            // Kartu tidak cocok - balik kembali setelah delay
            setTimeout(() => {
                card1.classList.remove('flipped');
                card2.classList.remove('flipped');
            }, 1000);
        }
        
        flippedCards = [];
        canFlip = true;
    }

    // Fungsi untuk menampilkan pesan kemenangan
    function showWinMessage() {
        // Stop background music saat menang
        stopBackgroundMusic();
        
        // Play win sound
        playSound(winSound);
        
        finalTimeElement.textContent = formatTime(levelConfig[currentLevel].time - timeLeft);
        finalMovesElement.textContent = moves;
        finalLevelElement.textContent = levelConfig[currentLevel].name;
        winMessage.classList.remove('hidden');
    }

    // Fungsi untuk menampilkan pesan kekalahan
    function showLoseMessage() {
        // Stop background music saat kalah
        stopBackgroundMusic();
        
        // Play lose sound
        playSound(loseSound);
        
        loseLevelElement.textContent = levelConfig[currentLevel].name;
        losePairsElement.textContent = matchedPairs;
        loseMessage.classList.remove('hidden');
    }

    // Fungsi untuk kembali ke pemilihan level
    function goToLevelSelection() {
        // Stop semua sound effects
        stopAllSoundEffects();
        
        // Kembali ke layar pemilihan level
        levelSelection.classList.remove('hidden');
        gameInfo.classList.add('hidden');
        gameTable.classList.add('hidden');
        winMessage.classList.add('hidden');
        loseMessage.classList.add('hidden');
        
        // Mulai background music saat kembali ke pemilihan level
        resumeBackgroundMusic();
    }

    // Event listener untuk tombol restart
    restartButton.addEventListener('click', () => {
        // Stop semua sound effects sebelum restart
        stopAllSoundEffects();
        startGame(currentLevel);
    });

    // Event listener untuk tombol ganti level
    changeLevelButton.addEventListener('click', goToLevelSelection);

    // Event listener untuk tombol play again
    playAgainButton.addEventListener('click', () => {
        // Stop semua sound effects sebelum restart
        stopAllSoundEffects();
        startGame(currentLevel);
    });

    // Event listener untuk tombol new level
    newLevelButton.addEventListener('click', goToLevelSelection);

    // Event listener untuk tombol retry
    retryButton.addEventListener('click', () => {
        // Stop semua sound effects sebelum restart
        stopAllSoundEffects();
        startGame(currentLevel);
    });

    // Event listener untuk tombol ganti level dari layar kalah
    loseChangeLevelButton.addEventListener('click', goToLevelSelection);

    // Inisialisasi sound ketika halaman dimuat
    initializeSound();
});